import redis
import os

def main(): 
    
    # redis_host = os.environ["redis_host"]
    # redis_key_to_be_deleted = os.environ["redis_key_to_be_deleted"]
    # print(event)

    try:
        r = redis.Redis(host=redis_host, port=6379)  
        print('Connection established')
    except:
        print('Could not establish redis connection, check connection string')
        raise

    event = "abc"
    for i in event.get("Records"):
        key_name = (event.get("Records")[i].get("s3").get("object").get("key")).split("/")[1].split(".")[0]
        print(key_name)    
        
            
        try:
            r.delete(redis_key_to_be_deleted)
            print(redis_key_to_be_deleted + ' key deleted')
        except:
            print('Could not delete key, check if it exists')
            raise

if __name__ == "__main__":
    main()