import requests, json, boto3, os

base_url = "https://private-monitoring.stage.oski.io"
api_key = "b2ufrHrCpbYAvacBEKkpUuYlNJbWCH3vHx4prat8"
application_name = "Hotel-Devops"
region = "us-east-1"
application_id = "73e066a5-42c7-4efb-a134-7908f1de2e8a"
environment = "prod"
mattermost_template = "pci_infra_alarm_state"
twilio_account_id = "ce5b6feb-62de-4d1b-ab67-50196c5e14a6"
mattermost_account_id = "bd0b0ff5-6f20-4ef9-9ac4-497e57dd4d8f"
    

def create_mapping(instance_name, alarm_name, type_of_metric):
    try:
        mapping_url = "".join([os.environ['base_url'], "/app/application%2F", os.environ['application_id'] , "/chatops/api/alarms"])
        params = {'apikey':os.environ['api_key']}
        data = json.dumps(create_json_data(os.environ['environment'], os.environ['application_name'], alarm_name,instance_name, os.environ['mattermost_template'], type_of_metric))
        headers = {'Content-type': 'application/json'}
        response = requests.post(url=mapping_url, data= data, headers=headers, params=params)
        response.raise_for_status()
    except requests.exceptions.HTTPError as exception:
        print(exception.args[0])
        print(exception.response.text)
    except Exception as exception:
        raise exception

def create_json_data( environment, application_name, alarm_name, instance_name, mattermost_template, type_of_metric):
    try:
        mapping_data = {
                    "Name": alarm_name,
                    "Application": application_name,
                    "Environment": environment,
                    "Friendlyname":alarm_name,
                    "Source": "cloudwatch"
                }
        mapping_data["OnFailureHandlerConfigurations"] =  [mattermost_mapping(mattermost_template), twilio_mapping(instance_name, type_of_metric)]
        mapping_data["OnRecoveryHandlerConfigurations"] = []
        return mapping_data
    except Exception as exception:
        raise exception

def twilio_mapping(instance_name, type_of_metric):
    try:
        return  {
            "Type": "twilio",
            "AccountId":  os.environ['twilio_account_id'],
            "ChannelAccountId": os.environ['mattermost_account_id'],
            "Message": "".join(["Observed High", type_of_metric , "Utilization on Oski", instance_name]), 
            "TemplateName": "twilio"
            }
    except Exception as exception:
        raise exception    

def mattermost_mapping(template_name):
    try:
        return {
                "Type": "mattermost",
                "AccountId": os.environ['mattermost_account_id'],
                "Template": template_name
                }
    except Exception as exception:
        raise exception    