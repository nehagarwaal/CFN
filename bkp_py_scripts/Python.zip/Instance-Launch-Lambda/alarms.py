import boto3
import os

def create_alarm(type_of_metric, instance_name, instance_id, statistics):
    try:
        client = boto3.client('cloudwatch')
        alarm_name = "-".join([ instance_name, type_of_metric, "utilization-high-alarm", instance_id])
        alarm_name = alarm_name.replace(" ", "")
        reponse = client.put_metric_alarm(
            AlarmName=alarm_name.lower(),
            AlarmDescription=alarm_name.lower(),
            ActionsEnabled=True,
            AlarmActions=[
                            os.environ['sns_topic'],
                        ],
            MetricName=statistics[type_of_metric][3],
            Namespace=statistics[type_of_metric][2],
            Statistic=statistics[type_of_metric][0],
            Period=300,
            EvaluationPeriods=2,
            DatapointsToAlarm=2,
            Threshold=statistics[type_of_metric][1],
            ComparisonOperator='GreaterThanOrEqualToThreshold',
            TreatMissingData='missing',
            Dimensions=statistics[type_of_metric][4]
        )
        return alarm_name.lower()
    except Exception as exception:
        print(exception)