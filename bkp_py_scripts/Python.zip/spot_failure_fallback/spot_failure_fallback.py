import json
import boto3
import random

asg_client = boto3.client('autoscaling')
ssm_client = boto3.client('ssm')

eks_asg_list=[]
failed_asg_name=""

def get_eks_asg():

    paginator = asg_client.get_paginator('describe_auto_scaling_groups')
    page_iterator = paginator.paginate(
        PaginationConfig={'PageSize': 100}
    )
    filtered_asgs = page_iterator.search(
    'AutoScalingGroups[] | [?contains(Tags[?Key==`{}`].Value, `{}`)]'.format(
        'Name', 'eks-travel-stage')
    )

    scaleup_count_failed = calculate_scaleup_count_failed(filtered_asgs)

    for asg in filtered_asgs:        
        if (asg['AutoScalingGroupName'].find("kiam") == -1 and asg['AutoScalingGroupName'] != failed_asg_name): 
            asg_details = {
                "name" : asg['AutoScalingGroupName'],
                "capacity" : asg["MaxSize"]-asg["DesiredCapacity"]
            }
            if asg_details.get("capacity") >= scaleup_count_failed:
                eks_asg_list.append(asg_details)        
    print("ASGs that can be scaled are:")   
    print(eks_asg_list)
    select_asg_to_scale(scaleup_count_failed)

def calculate_scaleup_count_failed(filtered_asgs):
    for asg in filtered_asgs:
        length=0
        scaleup_count_failed=0
        if (asg['AutoScalingGroupName'] == failed_asg_name):
            for instance in asg['Instances']:
                if (instance.get("LifecycleState") == 'InService' or instance.get("LifecycleState") == 'Pending'):
                    length = length + 1
            scaleup_count_failed = asg["DesiredCapacity"] - length
    return scaleup_count_failed

def select_asg_to_scale(scaleup_count_failed):
    asg_to_scale=random.choice(eks_asg_list)
    print("Selecting " + asg_to_scale + " for scale up")
    asg_client.set_desired_capacity(
        AutoScalingGroupName=asg_to_scale,
        DesiredCapacity=scaleup_count_failed,
        HonorCooldown=False
    )  

def lambda_handler(event, context):
    reason=json.loads(event.get("Records")[0].get("Sns").get("Message"))
    des=reason.get("Description")
    failed_asg_name=reason.get("AutoScalingGroupARN").split("autoScalingGroupName/",1)[1]
    response = ssm_client.get_parameter(
    Name='string',
    WithDecryption=True|False
)
    if(des.find("Launching a new EC2 instance. Status Reason: Could not launch Spot Instances. UnfulfillableCapacity - There is no capacity available that matches your request. Launching EC2 instance failed.") == 0):
        get_eks_asg()