import boto3
import re
import os
from mappings import *
from alarms import *

list_of_asg = ["carbe-v*","carcontentservice-v*","carsconnector-v*"]
list = ["cpu", "memory", "disk"]

def get_name_tag_from_asg(client , autoscalinggroup_name):
    try:
        response = client.describe_auto_scaling_groups(
                    AutoScalingGroupNames=[
                                            autoscalinggroup_name,
                    ],
        )
        asg = response.get('AutoScalingGroups')
        tags = asg[0]['Tags']
        for tag in tags:
            if tag['Key'] == "Name":
                return tag['Value']
    except Exception as exception:
        print(exception)

def delete_alarms_and_mappings( instance_id, instance_name):
    try:

        for metric in list:
            alarm_name = "-".join([ instance_name, metric, "utilization-high-alarm", instance_id])
            alarm_name = alarm_name.replace(" ", "")
            delete_mapping(alarm_name.lower())
            delete_alarm(alarm_name.lower())          
    except Exception as exception:
        print(exception)

def lambda_handler(event, context):
    try:
        autoscalinggroup_name = event.get('detail')['AutoScalingGroupName']
        instance_id =  event.get('detail')['EC2InstanceId']
        client = boto3.client('autoscaling')
        instance_name = get_name_tag_from_asg(client , autoscalinggroup_name)
        for asg in list_of_asg:
            pattern = re.compile(asg)
            if pattern.match(autoscalinggroup_name):
                delete_alarms_and_mappings(str(instance_id), str(instance_name))
                print("Alarms and Mappings are Deleted")
    except Exception as exception:
        print(exception)
        print("Unable to Delete Alarms and Mappings")