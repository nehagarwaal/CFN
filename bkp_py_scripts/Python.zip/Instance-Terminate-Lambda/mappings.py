import requests, json, boto3, os

base_url = "https://public-monitoring.stage.oski.io"
api_key = "b2ufrHrCpbYAvacBEKkpUuYlNJbWCH3vHx4prat8"
application_name = "Hotel-Loyalty-DevOps"
region = "us-east-1"
application_id = "96ceb8ae-f5a0-4d14-98ef-805ccb11de3f"
environment = "prod"
    

def delete_mapping(alarm_name):
    try:
        mapping_url = "".join([os.environ['base_url'], "/app/application%2F", os.environ['application_id'] , "/chatops/api/alarms/", os.environ['application_name'],"/", os.environ['environment'],"/cloudwatch/", alarm_name])
        params = {'apikey':os.environ['api_key']}
        headers = {'Content-type': 'application/json'}
        response = requests.delete(url=mapping_url, params=params)
        response.raise_for_status()
    except requests.exceptions.HTTPError as exception:
        print(exception.args[0])
        print(exception.response.text)
    except Exception as exception:
        raise exception
