import boto3
import os

def delete_alarm(alarm_name):
    try:
        client = boto3.client('cloudwatch')
        reponse = client.delete_alarms(
            AlarmNames=[alarm_name])
        return alarm_name.lower()
    except Exception as exception:
        print(exception)